const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

function loadFrames(prefix, count) {
    const frames = [];
    for (let i = 1; i <= count; i++) {
        const img = new Image();
        img.src = `sprites/${prefix}${i}.png`;
        frames.push(img);
    }
    return frames;
}

// ============== Animaciones jugador ==============
const animations = {
    idle: loadFrames("idle", 6),
    runDown: loadFrames("rundown", 6),
    runUp: loadFrames("runup", 6),
    runLeft: loadFrames("runleft", 6),
    runRight: loadFrames("runright", 6),
    attackDown: loadFrames("Ataqueabajo", 6),
    attackLeft: loadFrames("Ataqueizquierda", 6),
    attackRight: loadFrames("Ataquederecha", 6)
};

// ============== Animaciones esqueletos ==============
const skeletonAnims = {
    left: loadFrames("skeletonleft", 13),
    right: loadFrames("skeletonright", 13)
};

// ============== Estado de juego ==============
let gameState = "playing";

// ============== Jugador ==============
const player = {
    x: 0, y: 0,
    speed: 3,
    frame: 0,
    frameTimer: 0,
    frameInterval: 10,
    state: "idle",
    attacking: false,
    attackFrame: 0,
    attackTimer: 0,
    attackInterval: 6,
    lives: 3,
    maxLives: 3,
    invulnerable: false,
    invulTime: 0 
};

// ============== Fondo ==============
const grass = new Image();
grass.src = "sprites/pasto.png";
const tileSize = 260;

// ============== Enemigos ==============
const enemies = [];
let spawnCounter = 0;
const SPAWN_EVERY_FRAMES = 120;

function spawnSkeleton() {
    const dist = 800;
    const ang = Math.random() * Math.PI * 2;
    enemies.push({
        x: player.x + Math.cos(ang) * dist,
        y: player.y + Math.sin(ang) * dist,
        speed: 1.5,
        frame: 0,
        frameTimer: 0,
        frameInterval: 6,
        alive: true,
        hp: 2,
        dir: "left",
        radius: 24
    });
}

// ============== Controles ==============
const keys = {};
window.addEventListener("keydown", e => {
    const k = e.key.toLowerCase();
    keys[k] = true;

    if (gameState === "gameover" && (k === "r" || k === " ")) {
        restartGame();
        return;
    }

    if (k === "j" && !player.attacking && gameState === "playing") {
        startAttack();
    }
});
window.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

// ============== Ataque ==============
function startAttack() {
    player.attacking = true;
    player.attackFrame = 0;
    player.attackTimer = 0;
    if (keys["a"]) player.state = "attackLeft";
    else if (keys["d"]) player.state = "attackRight";
    else player.state = "attackDown";
}

// ============== Update Jugador ==============
function updatePlayer() {
    if (gameState !== "playing") return;

    // Invulnerable
    if (player.invulnerable) {
        player.invulTime--;
        if (player.invulTime <= 0) {
            player.invulnerable = false;
            player.invulTime = 0;
        }
    }

    // Ataque
    if (player.attacking) {
        player.attackTimer++;
        if (player.attackTimer >= player.attackInterval) {
            player.attackFrame++;
            player.attackTimer = 0;
        }
        if (player.attackFrame >= animations[player.state].length) {
            player.attacking = false;
            player.state = "idle";
            player.frame = 0;
        } else {
            player.frame = player.attackFrame;
        }
        return;
    }

    let moving = false;
    if (keys["w"]) { player.y -= player.speed; player.state = "runUp"; moving = true; }
    if (keys["s"]) { player.y += player.speed; player.state = "runDown"; moving = true; }
    if (keys["a"]) { player.x -= player.speed; player.state = "runLeft"; moving = true; }
    if (keys["d"]) { player.x += player.speed; player.state = "runRight"; moving = true; }
    if (!moving) player.state = "idle";

    // Animacion idle
    player.frameTimer++;
    if (player.frameTimer >= player.frameInterval) {
        player.frame = (player.frame + 1) % animations[player.state].length;
        player.frameTimer = 0;
    }
}

// ============== Update enemigos ==============
function updateEnemies() {
    if (gameState !== "playing") return;

    // Spawn 
    spawnCounter++;
    if (spawnCounter > SPAWN_EVERY_FRAMES) {
        spawnSkeleton();
        spawnCounter = 0;
    }

    enemies.forEach(e => {
        if (!e.alive) return;

        const dx = player.x - e.x;
        const dy = player.y - e.y;
        const dist = Math.hypot(dx, dy);

        e.dir = (e.x < player.x) ? "right" : "left";

        // Movimiento hacia el jugador
        if (dist > 1) {
            e.x += (dx / dist) * e.speed;
            e.y += (dy / dist) * e.speed;
        }

        // Daño por contacto
        if (dist < e.radius + 20 && !player.invulnerable) {
            player.lives = Math.max(0, player.lives - 1);
            player.invulnerable = true;
            player.invulTime = 60; // ~1s
            e.alive = false;

            if (player.lives <= 0) {
                gameState = "gameover";
            }
        }

        // Animacion caminar
        e.frameTimer++;
        if (e.frameTimer >= e.frameInterval) {
            e.frame = (e.frame + 1) % 13;
            e.frameTimer = 0;
        }

        // Daño por ataque del jugador en frame de impacto
        if (player.attacking && player.attackFrame === 3) {
            const ax = e.x - player.x;
            const ay = e.y - player.y;
            if (Math.hypot(ax, ay) < 100) {
                e.hp--;
                if (e.hp <= 0) e.alive = false;
            }
        }
    });
}

// ============== Fondo ==============
function drawBackground(offsetX, offsetY) {
    const startX = - (offsetX % tileSize) - tileSize;
    const startY = - (offsetY % tileSize) - tileSize;
    for (let y = startY; y < canvas.height + tileSize; y += tileSize) {
        for (let x = startX; x < canvas.width + tileSize; x += tileSize) {
            ctx.drawImage(grass, x, y, tileSize, tileSize);
        }
    }
}

// ============== Jugador ==============
function drawPlayer() {
    // Parpadeo visual
    if (player.invulnerable && Math.floor(player.invulTime / 5) % 2 === 0) {
        return; 
    }

    const frames = animations[player.state];
    const frameImg = frames[player.frame];
    const baseHeight = (player.state.includes("attack")) ? 110 : 100;
    const scale = baseHeight / frameImg.height;
    const drawWidth = frameImg.width * scale;

    ctx.drawImage(
        frameImg,
        canvas.width / 2 - drawWidth / 2,
        canvas.height / 2 - baseHeight / 2,
        drawWidth, baseHeight
    );
}

// ============== Enemigos ==============
function drawEnemies(offsetX, offsetY) {
    enemies.forEach(e => {
        if (!e.alive) return;
        const frameImg = skeletonAnims[e.dir][e.frame];
        ctx.drawImage(frameImg, e.x - offsetX - 33, e.y - offsetY - 64, 66, 128);
    });
}

// ============== HUD ==============
function drawHeart(x, y, size, fillStyle, strokeStyle) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(size / 100, size / 100);
    ctx.beginPath();
    ctx.moveTo(50, 30);
    ctx.bezierCurveTo(35, 0, 0, 0, 0, 30);
    ctx.bezierCurveTo(0, 55, 25, 72, 50, 90);
    ctx.bezierCurveTo(75, 72, 100, 55, 100, 30);
    ctx.bezierCurveTo(100, 0, 65, 0, 50, 30);
    ctx.closePath();
    ctx.fillStyle = fillStyle;
    ctx.fill();
    if (strokeStyle) {
        ctx.lineWidth = 6;
        ctx.strokeStyle = strokeStyle;
        ctx.stroke();
    }
    ctx.restore();
}

function drawLivesHUD() {
    const size = 28;
    const margin = 12;
    const startX = 16;
    const y = 16;

    for (let i = 0; i < player.maxLives; i++) {
        if (i < player.lives) {
            drawHeart(startX + i * (size + margin), y, size, "#e63946", "#7a1b23"); // lleno
        } else {
            drawHeart(startX + i * (size + margin), y, size, "#3a3a3a", "#555"); // vacío
        }
    }
}

// ============== Game Over ==============
function drawGameOverOverlay() {
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#fff";
    ctx.textAlign = "center";
    ctx.font = "bold 48px sans-serif";
    ctx.fillText("GAME OVER", canvas.width / 2, canvas.height / 2 - 20);

    ctx.font = "24px sans-serif";
    ctx.fillText("Presiona R o Espacio para reiniciar", canvas.width / 2, canvas.height / 2 + 24);
    ctx.restore();
}

// ============== Reiniciar ==============
function restartGame() {
    player.x = 0; player.y = 0;
    player.state = "idle";
    player.frame = 0;
    player.attacking = false;
    player.attackFrame = 0;
    player.attackTimer = 0;
    player.lives = player.maxLives;
    player.invulnerable = false;
    player.invulTime = 0;

    enemies.length = 0;
    spawnCounter = 0;

    gameState = "playing";
}

// ============== Game Loop ==============
function update() {
    if (gameState !== "playing") return;
    spawnCounter++;
    if (spawnCounter > SPAWN_EVERY_FRAMES) {
        spawnSkeleton();
        spawnCounter = 0;
    }
    updatePlayer();
    updateEnemies();
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const offsetX = player.x - canvas.width / 2;
    const offsetY = player.y - canvas.height / 2;

    drawBackground(offsetX, offsetY);
    drawEnemies(offsetX, offsetY);
    drawPlayer();
    drawLivesHUD();

    if (gameState === "gameover") {
        drawGameOverOverlay();
    }
}

function gameLoop() {
    if (gameState === "playing") update();
    draw();
    requestAnimationFrame(gameLoop);
}
gameLoop();
